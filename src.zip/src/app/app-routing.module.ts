import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { moduleRoutes } from './shared';
import { HomeComponent } from './modules/home/home/home.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'auth/login',
    pathMatch: 'full'
  },
  { 
    path: 'auth',
    loadChildren: 'src/app/modules/auth/auth.module#AuthModule'
  },
  {
    path: 'home',
    component: HomeComponent,
    // canActivate: [AuthGuard],
    children: moduleRoutes
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
