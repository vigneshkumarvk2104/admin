import { Routes } from '@angular/router';

export const moduleRoutes : Routes = [
    {path:'dashboard',loadChildren:'src/app/modules/dashboard/dashboard.module#DashboardModule'},
    {path:'userManagement',loadChildren:'src/app/modules/usermanagement/usermanagement.module#UsermanagementModule'}
];