import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/core/services';
import { tap, map, finalize, catchError, } from 'rxjs/operators';
import { of, throwError, from } from 'rxjs';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private apiservice: ApiService) { }

  ngOnInit() {
  }

  login(email,pwd){
    this.apiservice.post('/api/v1/users', {email_id :email,password:pwd}).pipe(
      tap(entitlements => {
        console.log(entitlements);
      })
    ).subscribe();
  }

}
